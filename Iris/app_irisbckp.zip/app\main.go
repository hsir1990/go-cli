package main

import (
	"fmt"

	"github.com/kataras/iris"
)

func main() {
	//1创建一个app结构体对象，源码中New出一个结构体对象
	app := iris.New()

	//2端口监听  //自定义端口    //如果没有这个端口回提示错误
	app.Run(iris.Addr(":8000"), iris.WithoutServerError(iris.ErrServerClosed))

	// //也可以这么写
	// app.Run(iris.Addr(":7999"))

	app.Get("/getRequest", func(context iris.Context) {
		fmt.Println("11")
		//处理get请求，请求的url为 /getRequest
		path := context.Path()
		app.Logger().Info(path)
	})
}
